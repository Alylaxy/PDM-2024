package iesb.app.sqliteapp.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

import iesb.app.sqliteapp.MainActivity;
import iesb.app.sqliteapp.model.ClienteVO;

public class DataBaseHandler extends SQLiteOpenHelper {
    private static final int DATA_BASE_VERSION = 1;
    private static final String DATA_BASE_NAME = "DB_EOQ";
    private static final String TB_CLIENTES = "tb_clientes";
    private static final String KEY_ID = "id";
    private static final String NOME = "nome";
    private static final String EMAIL = "email";

    //Constructor
    public DataBaseHandler(Context context) {
        super(context, DATA_BASE_NAME, null, DATA_BASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTbClientes = "CREATE TABLE " + TB_CLIENTES + " (" +
                KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                NOME   + " TEXT, " +
                EMAIL  + " TEXT)";
        db.execSQL(createTbClientes);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TB_CLIENTES);
        onCreate(db);
    }

    public void addCliente(ClienteVO clienteVO) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(NOME, clienteVO.getNome());
        contentValues.put(EMAIL, clienteVO.getEmail());

        db.insert(TB_CLIENTES, null, contentValues);
        db.close();
    }

    public int getCountClientes() {
        int count = 0;
        String countQuery = "SELECT COUNT(*) FROM " + TB_CLIENTES;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        count = cursor.getCount();
        cursor.close();
        db.close();

        return count;
    }

    public List<ClienteVO> getAllClientes() {
        List<ClienteVO> ltClientes = new ArrayList<ClienteVO>();
        String selectQuery = "SELECT * FROM " + TB_CLIENTES;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                ClienteVO clienteVO = new ClienteVO();
                clienteVO.setId(Integer.parseInt(cursor.getString(0)));
                clienteVO.setNome(cursor.getString(1));
                clienteVO.setEmail(cursor.getString(2));

                ltClientes.add(clienteVO);
            } while (cursor.moveToNext());
        }
        return null;
    }
}



